#include "tdas/list.h"
#include <ctype.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
   int hora;
   int minuto;
   int segundo;
} tiempo;

typedef struct {
  tiempo time;
  char prioridad[20];
} llegada;

typedef struct {
  char nombre[20];
  int edad;
  char sintoma[20];
  llegada lugar;
} Pacientes;

int largo_lista(List *lista){
  int cont = 0;
  Pacientes *paciente = list_first(lista);
  while (paciente != NULL) {
    cont ++;
    paciente = list_next(lista);
  }
  return cont;
}
void mayus(char *texto){
  while(*texto){
    *texto = toupper(*texto);
    texto++;
  }
}
int cmp(void *data1, void *data2) {
    Pacientes *paciente1 = (Pacientes *)data1;
    Pacientes *paciente2 = (Pacientes *)data2;
    int prioridad1, prioridad2;
    if (strcmp(paciente1->lugar.prioridad, "ALTA") == 0) {
        prioridad1 = 3;
    } 
    else if (strcmp(paciente1->lugar.prioridad, "MEDIA") == 0) {
        prioridad1 = 2;
    } 
    else if(strcmp(paciente1->lugar.prioridad, "BAJA") == 0) {
        prioridad1 = 1; 
    }
    if (strcmp(paciente2->lugar.prioridad, "ALTA") == 0) {
        prioridad2 = 3;
    } 
    else if (strcmp(paciente2->lugar.prioridad, "MEDIA") == 0) {
        prioridad2 = 2;
    } 
    else if(strcmp(paciente2->lugar.prioridad, "BAJA") == 0){
        prioridad2 = 1; 
    }
    if (prioridad1 != prioridad2) {
        return prioridad1 > prioridad2;
    }
    if (paciente1->lugar.time.hora != paciente2->lugar.time.hora) {
        return paciente1->lugar.time.hora < paciente2->lugar.time.hora;
    } 
    else if (paciente1->lugar.time.minuto != paciente2->lugar.time.minuto) {
        return paciente1->lugar.time.minuto < paciente2->lugar.time.minuto;
    } 
    else {
        return paciente1->lugar.time.segundo < paciente2->lugar.time.segundo;
    }
}
void mostrar_paciente(Pacientes *paciente){
  printf("\n--------------------------\n");
  printf("Nombre: %s\n", paciente->nombre);
  printf("Edad: %d\n", paciente->edad);
  printf("Sintoma: %s\n", paciente->sintoma);
  printf("Hora de llegada: %d:%d:%d\n", paciente->lugar.time.hora,paciente->lugar.time.minuto,paciente->lugar.time.segundo);
  printf("Prioridad: %s\n", paciente->lugar.prioridad);
  printf("--------------------------");
}
void registrar_paciente(List *lista) {
  Pacientes *paciente = (Pacientes *)malloc(sizeof(Pacientes));
  strcpy(paciente->lugar.prioridad, "BAJA");
  printf("Ingrese el nombre del paciente: ");
  scanf(" %s", paciente->nombre);
  mayus(paciente->nombre);
  printf("Ingrese la edad del paciente: ");
  scanf(" %d", &paciente->edad);
  printf("Ingrese sintoma del paciente: ");
  scanf(" %s", paciente->sintoma);
  time_t tiempo_actual = time(NULL);
  struct tm *hora_local = localtime(&tiempo_actual);
  paciente->lugar.time.minuto = hora_local->tm_min;
  paciente->lugar.time.segundo = hora_local->tm_sec;
  if(hora_local->tm_hour >= 4 ){
    paciente->lugar.time.hora = hora_local->tm_hour - 4;
  }
  else{
    paciente->lugar.time.hora = 24 + (hora_local->tm_hour - 4);
  }
  mostrar_paciente(paciente);
  list_pushBack(lista, paciente); 
}
void asignar_prioridad(List *lista) {
  if(largo_lista(lista) == 0){
    printf("No hay pacientes en la lista");
    return;
  }
  char nombre[20];
  printf("Nombre del paciente a buscar: ");
  scanf(" %s",nombre);
  mayus(nombre);
  Pacientes *paciente = list_first(lista);
  while (paciente != NULL) {
    char prioridad[6];
    if (strcmp(paciente->nombre, nombre) == 0){
      printf("PACIENTE ENCONTRADO!!\n");
      printf("Prioridad a asignar (ALTA,MEDIA,BAJA): ");
      scanf(" %s", prioridad);
      mayus(prioridad);
      strcpy(paciente->lugar.prioridad, prioridad);
      printf("\nPRIORIDAD ASIGNADA.");
      mostrar_paciente(paciente);
      list_popCurrent(lista);
      list_sortedInsert(lista,paciente,cmp);
      return;
    }
    paciente = list_next(lista);
  } 
  printf("\nPaciente no encontrado por favor reintente.");
}
void mostrarMenuPrincipal() {
  puts("\n\n******************************************");
  puts("     Sistema de Gestión Hospitalaria");
  puts("******************************************\n");
  puts("1. Registrar paciente");
  puts("2. Asignar prioridad a paciente");
  puts("3. Mostrar lista de espera");
  puts("4. Atender al siguiente paciente");
  puts("5. Mostrar pacientes por prioridad");
  puts("6. Salir\n");
}
void mostrar_lista(List *lista) {
  Pacientes *paciente = list_first(lista);
  printf("\nLISTA DE PACIENTES:\n");
  while (paciente != NULL) {
    mostrar_paciente(paciente);
    paciente = list_next(lista);
  }
}
void atender_paciente(List *lista){
  if(largo_lista(lista) == 0){
    printf("\nNo hay pacientes en la lista de espera.");
    return;
  }
  Pacientes *paciente = list_first(lista);
  printf("PACIENTE A ATENDER:");
  mostrar_paciente(paciente);
  list_popFront(lista);
  if(largo_lista(lista) == 0){
    printf("\nNo quedan pacientes en espera.");
  }
  else{
    printf("\nAún quedan %d pacientes en espera.",largo_lista(lista));
  }
}
void mostrar_por_prioridad(List *lista){
  int cont = 0;
  char prioridad[6];
  printf("Que prioridad desea ver(ALTA,MEDIA,BAJA):");
  scanf(" %s",prioridad);
  mayus(prioridad);
  Pacientes *paciente = list_first(lista);
  while (paciente != NULL) {
    if(strcmp(paciente->lugar.prioridad,prioridad)==0){
      cont = 1;
      mostrar_paciente(paciente);
    }
    paciente = list_next(lista);
  }
  if (cont == 0){
    printf("\nNo hay pacientes con esa prioridad\n");
  }
}
int main() {
  int opcion;
  List *pacientes = list_create();
  do {
    mostrarMenuPrincipal();
    printf("------------------------------------------\nIngrese su opción: ");
    char entrada;
    scanf(" %s", &entrada);
    if(isdigit(entrada)){
      opcion = entrada - '0';
      if(opcion >= 1 && opcion <= 6){
        while (getchar() != '\n');
        switch (opcion) {
        case 1:
          registrar_paciente(pacientes);
          break;
        case 2:
          asignar_prioridad(pacientes);
          break;
        case 3:
          mostrar_lista(pacientes);
          break;
        case 4:
          atender_paciente(pacientes);
          break;
        case 5:
         mostrar_por_prioridad(pacientes);
          break;
        }
      }
      else{
        printf("Opción no valida, vuelva a intentarlo.");
        continue;
      }
    }
    else{
      printf("Opción no valida, vuelva a intentarlo.");
      continue;
    }
  } while (opcion != '6');
  list_clean(pacientes);
  return 0;
}